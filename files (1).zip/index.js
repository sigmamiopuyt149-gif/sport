import { DurableObject } from "cloudflare:workers";

// แก้ชื่อสี/รหัสสีของทีมได้ที่นี่
const TEAMS = [
  { id: "red", name: "สีแดง", color: "#e53935" },
  { id: "blue", name: "สีน้ำเงิน", color: "#1e88e5" },
  { id: "green", name: "สีเขียว", color: "#43a047" },
  { id: "yellow", name: "สีเหลือง", color: "#f9a825" },
];

export class Scoreboard extends DurableObject {
  async getState() {
    return (await this.ctx.storage.get("state")) ?? { teams: TEAMS.map((t) => ({ ...t, score: 0 })), log: [] };
  }
  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === "/ws") {
      if (req.headers.get("Upgrade") !== "websocket") return new Response("Expected websocket", { status: 426 });
      const pair = new WebSocketPair();
      this.ctx.acceptWebSocket(pair[1]);
      pair[1].send(JSON.stringify(await this.getState()));
      return new Response(null, { status: 101, webSocket: pair[0] });
    }
    if (url.pathname === "/score" && req.method === "POST") {
      const { team, points, event } = await req.json();
      const s = await this.getState();
      const t = s.teams.find((x) => x.id === team);
      if (!t || !Number.isFinite(points)) return new Response("bad request", { status: 400 });
      t.score += points;
      s.log.unshift({ time: Date.now(), team: t.name, points, event: String(event || "").slice(0, 100) });
      s.log = s.log.slice(0, 50);
      await this.ctx.storage.put("state", s);
      const msg = JSON.stringify(s);
      for (const ws of this.ctx.getWebSockets()) { try { ws.send(msg); } catch {} }
      return Response.json(s);
    }
    return new Response("not found", { status: 404 });
  }
  webSocketMessage() {}
  webSocketClose(ws) { ws.close(); }
}

const STYLE = `<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:system-ui,"Noto Sans Thai",sans-serif;margin:0;padding:16px;background:#111;color:#fff;max-width:720px;margin:auto}
h1{text-align:center}.row{margin:14px 0}.bar{height:38px;border-radius:8px;transition:width .6s;display:flex;align-items:center;padding:0 12px;font-weight:700;color:#fff;min-width:60px}
.top{display:flex;justify-content:space-between;font-size:1.2rem}li{padding:4px 0;border-bottom:1px solid #333}ul{list-style:none;padding:0}
input,select,button{font:inherit;padding:10px;margin:4px 0;width:100%;box-sizing:border-box;border-radius:6px;border:0}button{background:#43a047;color:#fff;font-weight:700}
#st{color:#aaa;text-align:center;font-size:.85rem}</style>`;

const PUBLIC = `<!doctype html><html lang="th"><head><title>ผลกีฬาสี Live</title>${STYLE}</head><body>
<h1>🏆 ผลคะแนนกีฬาสี</h1><div id="st">กำลังเชื่อมต่อ...</div><div id="board"></div><h3>ความเคลื่อนไหวล่าสุด</h3><ul id="log"></ul>
<script>
function render(s){
  var max=Math.max.apply(null,s.teams.map(function(t){return t.score}).concat([1]));
  var b=document.getElementById("board");b.innerHTML="";
  s.teams.slice().sort(function(a,c){return c.score-a.score}).forEach(function(t,i){
    var r=document.createElement("div");r.className="row";
    var top=document.createElement("div");top.className="top";
    var n=document.createElement("span");n.textContent=(i+1)+". "+t.name;
    var p=document.createElement("span");p.textContent=t.score+" คะแนน";
    top.append(n,p);
    var bar=document.createElement("div");bar.className="bar";bar.style.background=t.color;
    bar.style.width=Math.max(8,t.score/max*100)+"%";
    r.append(top,bar);b.append(r);
  });
  var l=document.getElementById("log");l.innerHTML="";
  s.log.forEach(function(e){var li=document.createElement("li");
    li.textContent=new Date(e.time).toLocaleTimeString("th-TH")+" "+e.team+" "+(e.points>0?"+":"")+e.points+" "+e.event;l.append(li)});
}
function connect(){
  var ws=new WebSocket((location.protocol==="https:"?"wss://":"ws://")+location.host+"/ws");
  ws.onopen=function(){document.getElementById("st").textContent="🟢 อัปเดตแบบเรียลไทม์"};
  ws.onmessage=function(e){render(JSON.parse(e.data))};
  ws.onclose=function(){document.getElementById("st").textContent="🔴 หลุดการเชื่อมต่อ กำลังต่อใหม่...";setTimeout(connect,2000)};
}
connect();
</script></body></html>`;

const ADMIN = `<!doctype html><html lang="th"><head><title>แอดมินกีฬาสี</title>${STYLE}</head><body>
<h1>⚙️ บันทึกคะแนน</h1>
<input id="tok" type="password" placeholder="รหัสผ่านแอดมิน">
<select id="team">${TEAMS.map((t) => `<option value="${t.id}">${t.name}</option>`).join("")}</select>
<input id="pts" type="number" placeholder="คะแนน (ใส่ค่าลบเพื่อหักคะแนน)">
<input id="ev" placeholder="รายการแข่ง เช่น วิ่งผลัด ม.1">
<button onclick="send()">บันทึก</button><div id="st"></div>
<script>
document.getElementById("tok").value=sessionStorage.getItem("tok")||"";
function send(){
  var tok=document.getElementById("tok").value;sessionStorage.setItem("tok",tok);
  fetch("/api/score",{method:"POST",headers:{"Authorization":"Bearer "+tok,"Content-Type":"application/json"},
    body:JSON.stringify({team:document.getElementById("team").value,points:Number(document.getElementById("pts").value),event:document.getElementById("ev").value})})
  .then(function(r){document.getElementById("st").textContent=r.ok?"✅ บันทึกแล้ว":"❌ ผิดพลาด ("+r.status+")";if(r.ok){document.getElementById("pts").value="";document.getElementById("ev").value=""}});
}
</script></body></html>`;

const html = (body) => new Response(body, { headers: { "Content-Type": "text/html; charset=utf-8" } });

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const stub = env.SCOREBOARD.get(env.SCOREBOARD.idFromName("main"));
    if (url.pathname === "/ws") return stub.fetch(req);
    if (url.pathname === "/api/score" && req.method === "POST") {
      if (!env.ADMIN_TOKEN || req.headers.get("Authorization") !== `Bearer ${env.ADMIN_TOKEN}`)
        return new Response("unauthorized", { status: 401 });
      return stub.fetch(new Request("https://do/score", { method: "POST", body: req.body, headers: req.headers }));
    }
    if (url.pathname === "/admin") return html(ADMIN);
    return html(PUBLIC);
  },
};
